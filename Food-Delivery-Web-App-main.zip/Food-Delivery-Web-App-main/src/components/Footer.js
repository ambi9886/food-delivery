const Footer = () => {
  return (
    <div className="footer">
      <h1>Avail 20% off Now !</h1>
    </div>
  );
};

export default Footer;
